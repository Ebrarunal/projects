/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sonproje;

import java.util.Scanner;

/**
 *
 * @author Berkay Çetin
 */
public class SonProje {

    /**
     * Applies a promotion code to the cart total.
     *
     * This method prompts the user to enter a promotion code and applies
     * the corresponding discount to the cart total if the code is valid.
     * The method continues to prompt for additional codes until the user
     * decides to stop by entering a value other than 'E'.
     *
     * @param cartTotal the current total amount of the cart before applying any promotions
     * @return the updated cart total after applying the promotion(s)
     */



    public static double applyPromotion(double cartTotal) {
        Scanner input = new Scanner(System.in);
        String control;

        do {
            System.out.println("Enter your promotion code if you have one:");
            String promoCode = input.next();

            switch (promoCode) {
                case "E50":
                    cartTotal = cartTotal / 2;
                    System.out.println("Promotion applied.");
                    break;
                case "B20":
                    cartTotal = cartTotal - (cartTotal / 5);
                    System.out.println("Promotion applied.");
                    break;
                case "T10":
                    cartTotal = cartTotal - (cartTotal / 10);
                    System.out.println("Promotion applied.");
                    break;
                default:
                    System.out.println("Invalid promotion code.");
                    break;
            }

            System.out.println("Would you like to try another code? (Enter 'E' for Yes)");
            control = input.next();
        } while ("E".equals(control));

        return cartTotal;
    }

    public static double shoppingCart(double cartTotal) {
        Scanner input = new Scanner(System.in);
        String control1;
        String control2;
        String[] cart = new String[10];
        boolean sizeSelection = false;
        int index = 0;

        do {
            do {
                String[] categories = {
                    "Category    Category no",
                    "Jeans       1",
                    "Dress       2",
                    "Sweater     3",
                    "Sweatshirt  4"
                };

                for (int j = 0; j < categories.length; j++) {
                    System.out.printf("%-10s", categories[j] + "\t");
                    System.out.println();
                }

                System.out.println("\nPlease select a category:");
                String category = input.next();
                String size;

                switch (category) {
                    case "1":
                        String[][] jeans = {
                            {"Model", "Size", "Price", "Product Code"},
                            {"Regular Fit", "S-M-L", "400₺", "j01"},
                            {"Skinny Fit", "S-M-L", "250₺", "j02"},
                            {"Relaxed Fit", "S-M-L", "500₺", "j03"},
                            {"Cargo", "S-M-L", "690₺", "j04"},
                            {"Mom Fit", "S-M-L", "450₺", "j05"}
                        };
                        for (int i = 0; i < jeans.length; i++) {
                            for (int j = 0; j < jeans[i].length; j++) {
                                System.out.printf("%-25s", jeans[i][j]);
                            }
                            System.out.println();
                        }

                        System.out.println("\nPlease enter the product code of your choice:");
                        String productCode = input.next();
                        switch (productCode) {
                            case "j01":
                                System.out.println("\nRegular Fit added to your cart\n");
                                cartTotal += 400;
                                break;
                            case "j02":
                                System.out.println("\nSkinny Fit added to your cart\n");
                                cartTotal += 250;
                                break;
                            case "j03":
                                System.out.println("\nRelaxed Fit added to your cart\n");
                                cartTotal += 500;
                                break;
                            case "j04":
                                System.out.println("Cargo added to your cart");
                                cartTotal += 690;
                                break;
                            case "j05":
                                System.out.println("Mom Fit added to your cart");
                                cartTotal += 450;
                                break;
                            
                        }
                        do {
                            System.out.println("Please select a size:");
                            size = input.next();
                            switch (size) {
                                case "S":
                                    System.out.println("Size S selected.");
                                    sizeSelection = true;
                                    break;
                                case "M":
                                    System.out.println("Size M selected.");
                                    sizeSelection = true;
                                    break;
                                case "L":
                                    System.out.println("Size L selected.");
                                    sizeSelection = true;
                                    break;
                                default:
                                    System.out.println("Size not available or invalid input. Please try again.");
                                    break;
                            }
                        } while (!sizeSelection);
                        cart[index] = productCode;
                        index++;
                        break;

                    case "2":
                        String[][] dress = {
                            {"Model", "Size", "Price", "Product Code"},
                            {"Mini Dress", "S-M-L", "200₺", "e01"},
                            {"Slit Dress", "S-M-L", "200₺", "e02"}
                        };

                        for (int i = 0; i < dress.length; i++) {
                            for (int j = 0; j < dress[i].length; j++) {
                                System.out.printf("%-25s", dress[i][j]);
                            }
                            System.out.println();
                        }

                        System.out.println("Please enter the product code of your choice:");
                        productCode = input.next();
                        switch (productCode) {
                            case "e01":
                                System.out.println("Mini Dress added to your cart");
                                cartTotal += 200;
                                break;
                            case "e02":
                                System.out.println("Slit Dress added to your cart");
                                cartTotal += 200;
                                break;
                        }
                        do {
                            System.out.println("Please select a size:");
                            size = input.next();
                            switch (size) {
                                case "S":
                                    System.out.println("Size S selected.");
                                    sizeSelection = true;
                                    break;
                                case "M":
                                    System.out.println("Size M selected.");
                                    sizeSelection = true;
                                    break;
                                case "L":
                                    System.out.println("Size L selected.");
                                    sizeSelection = true;
                                    break;
                                default:
                                    System.out.println("Size not available or invalid input. Please try again.");
                                    break;
                            }
                        } while (!sizeSelection);
                        cart[index] = productCode;
                        index++;
                        break;

                    case "3":
                        String[][] sweater = {
                            {"Model", "Size", "Price", "Product Code"},
                            {"Furry Sweater", "S-M-L", "200₺", "k01"},
                            {"Oversize Sweater", "S-M-L", "250₺", "k02"},
                            {"Patterned Sweater", "S-M-L", "300₺", "k03"}
                        };

                        for (int i = 0; i < sweater.length; i++) {
                            for (int j = 0; j < sweater[i].length; j++) {
                                System.out.printf("%-25s", sweater[i][j]);
                            }
                            System.out.println();
                        }

                        System.out.println("Please enter the product code of your choice:");
                        productCode = input.next();
                        switch (productCode) {
                            case "k01":
                                System.out.println("\nFurry Sweater added to your cart\n");
                                cartTotal += 200;
                                break;
                            case "k02":
                                System.out.println("\nOversize Sweater added to your cart\n");
                                cartTotal += 250;
                                break;
                            case "k03":
                                System.out.println("\nPatterned Sweater added to your cart\n");
                                cartTotal += 300;
                                break;
                        }
                        do {
                            System.out.println("Please select a size:");
                            size = input.next();
                            switch (size) {
                                case "S":
                                    System.out.println("Size S selected.");
                                    sizeSelection = true;
                                    break;
                                case "M":
                                    System.out.println("Size M selected.");
                                    sizeSelection = true;
                                    break;
                                case "L":
                                    System.out.println("Size L selected.");
                                    sizeSelection = true;
                                    break;
                                default:
                                    System.out.println("Size not available or invalid input. Please try again.");
                                    break;
                            }
                        } while (!sizeSelection);
                        cart[index] = productCode;
                        index++;
                        break;

                    case "4":
                        String[][] sweatshirt = {
                            {"Model", "Size", "Price", "Product Code"},
                            {"Hooded Sweatshirt", "S-M-L", "100₺", "s01"},
                            {"Crop Sweatshirt", "S-M-L", "190₺", "s02"},
                            {"Printed Sweatshirt", "S-M-L", "210₺", "s03"},
                            {"Oversize Sweatshirt", "S-M-L", "105₺", "s04"},
                            {"Zippered Sweatshirt", "S-M-L", "75₺", "s05"}
                        };

                        for (int i = 0; i < sweatshirt.length; i++) {
                            for (int j = 0; j < sweatshirt[i].length; j++) {
                                System.out.printf("%-25s", sweatshirt[i][j]);
                            }
                            System.out.println();
                        }

                        System.out.println("Please enter the product code of your choice:");
                        productCode = input.next();
                        switch (productCode) {
                            case "s01":
                                System.out.println("\nHooded Sweatshirt added to your cart\n");
                                cartTotal += 100;
                                break;
                            case "s02":
                                System.out.println("\nCrop Sweatshirt added to your cart\n");
                                cartTotal += 190;
                                break;
                            case "s03":
                                System.out.println("\nPrinted Sweatshirt added to your cart\n");
                                cartTotal += 210;
                                break;
                            case "s04":
                                System.out.println("\nOversize Sweatshirt added to your cart\n");
                                cartTotal += 105;
                                break;
                            case "s05":
                                System.out.println("\nZippered Sweatshirt added to your cart\n");
                                cartTotal += 75;
                                break;
                        }
                        do {
                            System.out.println("Please select a size:");
                            size = input.next();
                            switch (size) {
                                case "S":
                                    System.out.println("Size S selected.");
                                    sizeSelection = true;
                                    break;
                                case "M":
                                    System.out.println("Size M selected.");
                                    sizeSelection = true;
                                    break;
                                case "L":
                                    System.out.println("Size L selected.");
                                    sizeSelection = true;
                                    break;
                                default:
                                    System.out.println("Size not available or invalid input. Please try again.");
                                    break;
                            }
                        } while (!sizeSelection);
                        cart[index] = productCode;
                        index++;
                        break;
                }

                System.out.println("Would you like to add more items to your cart? (Enter 'E' for Yes)");
                control1 = input.next();
            } while ("E".equals(control1));

            System.out.println("Would you like to checkout? (Enter 'Q' for Yes)");
            control2 = input.next();
        } while (!"Q".equals(control2));

        return cartTotal;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Welcome");
        System.out.println("Please Register\n");
        String[] array = new String[3];
        System.out.println("Name and Surname");
        array[0] = input.nextLine();
        double cartTotal = 0;
        // String control2=null;
        do {
            System.out.println("T.C Identity Number");
            array[1] = input.nextLine();
        } while (array[1].length() != 11);

        System.out.println("Create a Password");
        array[2] = input.nextLine();

        // Logging In
        System.out.println("\nLog In");
        String identityNumber;
        String password;
        boolean loginSuccessful = false;

        do {
            System.out.println("\nEnter your T.C Identity Number:");
            identityNumber = input.nextLine();
            System.out.println("Enter your Password");
            password = input.nextLine();
            if (password.equals(array[2]) && identityNumber.equals(array[1])) {
                loginSuccessful = true;
            } else {
                System.out.println("Please try again");
            }
        } while (!loginSuccessful);

        if (loginSuccessful) {
            System.out.println("Login Successful\n ");
            System.out.println("Welcome " + array[0] + "\n");
        }

        cartTotal = shoppingCart(cartTotal);
        double finalTotal = applyPromotion(cartTotal);

        // PAYMENT METHOD
        System.out.printf("Your updated cart total is = %.2f ₺", finalTotal);
        System.out.println("");
        System.out.println("            HOME DELIVERY    BRANCH DELIVERY");
        System.out.println("\n1.Yurtiçi:  79.90₺          59.90₺\n2.MNG Cargo: 99.90₺          79.90₺\n3.Aras Cargo: 59.90₺          39.90₺\n");
        int cargo = input.nextInt();
        String homeAddress = null;
        String branchAddress = null;
        boolean deliverySelectionSuccessful = false;

        do {
            System.out.println("Please select the delivery type\n");
            System.out.println("1-Home delivery\n2-Branch delivery");
            int deliverySelection = input.nextInt();

            if (deliverySelection != 1 && deliverySelection != 2) {
                System.out.println("Please choose between 1 and 2");
                continue;
            }

            if (deliverySelection == 1) {
                switch (cargo) {
                    case 1:
                        System.out.println("Enter your home address");
                        homeAddress = input.next();
                        finalTotal += 79.90;
                        System.out.println(finalTotal);
                        deliverySelectionSuccessful = true;
                        break;
                    case 2:
                        System.out.println("Enter your home address");
                        homeAddress = input.next();
                        finalTotal += 99.90;
                        System.out.println(finalTotal);
                        deliverySelectionSuccessful = true;
                        break;
                    case 3:
                        System.out.println("Enter your home address");
                        homeAddress = input.next();
                        finalTotal += 59.90;
                        System.out.println(finalTotal);
                        deliverySelectionSuccessful = true;
                        break;
                }
            } else if (deliverySelection == 2) {
                switch (cargo) {
                    case 1:
                        System.out.println("Enter the address of the nearest Yurtiçi cargo branch");
                        branchAddress = input.next();
                        finalTotal += 59.90;
                        System.out.println(finalTotal);
                        deliverySelectionSuccessful = true;
                        break;
                    case 2:
                        System.out.println("Enter the address of the nearest MNG cargo branch");
                        branchAddress = input.next();
                        finalTotal += 79.90;
                        System.out.println(finalTotal);
                        deliverySelectionSuccessful = true;
                        break;
                    case 3:
                        System.out.println("Enter the address of the nearest Aras cargo branch");
                        branchAddress = input.next();
                        finalTotal += 39.90;
                        System.out.println(finalTotal);
                        deliverySelectionSuccessful = true;
                        break;
                }
            }
        } while (!deliverySelectionSuccessful);

        String address = null;
        if (homeAddress != null) {
            address = homeAddress;
        } else {
            address = branchAddress;
        }

        long cardNumber;
        String cardExpiryDate = null;
        String ccv;
        boolean cardDetailsSuccessful = false;

        do {
            System.out.println("Select Payment Method");
            System.out.println("1-Card Payment\n2-Cash on Delivery");
            int paymentMethod = input.nextInt();

            if (paymentMethod != 1 && paymentMethod != 2) {
                System.out.println("Please choose between 1 and 2");
                continue;
            }

            if (paymentMethod == 1) {
                System.out.println("Enter your card details");
                do {
                    System.out.println("Enter your 16-digit card number");
                    cardNumber = input.nextLong();
                } while (String.valueOf(cardNumber).length() != 16);
                do {
                    System.out.println("Enter your card's expiry date in MM/YY format");
                    cardExpiryDate = input.next();
                } while (cardExpiryDate.length() != 5);
                do {
                    System.out.println("Enter your card's 3-digit CCV code on the back");
                    ccv = input.next();
                } while (ccv.length() != 3);

                cardDetailsSuccessful = true;
                break;
            } else if (paymentMethod == 2) {
                System.out.println("Your request for Cash on Delivery has been received");
                break;
               
            }
        } while (!cardDetailsSuccessful);
        System.out.println("Payment Successful ");
    }
}

    

