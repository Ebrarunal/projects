package pack1;

import java.awt.*;
import javax.swing.*;

public class LoanTransactions {

    private JFrame frame;
    private User user;

    public LoanTransactions(User user) {
        this.user = user;
        initialize();
        frame.setVisible(true);
    }

    private void initialize() {
        frame = new JFrame("Loan Transactions");
        frame.setBounds(100, 100, 500, 350);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        frame.getContentPane().setBackground(new Color(234, 246, 255)); // #EAF6FF

        JLabel titleLabel = new JLabel("Loan Services");
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 22));
        titleLabel.setForeground(new Color(30, 60, 90));
        titleLabel.setBounds(160, 25, 200, 30);
        frame.getContentPane().add(titleLabel);

        JButton creditBtn = new JButton("My Loans");
        styleButton(creditBtn, new Color(173, 216, 230)); // Light Blue
        creditBtn.setBounds(160, 80, 160, 35);
        creditBtn.addActionListener(e -> {
            frame.dispose();
            new MyLoansPage(user);
        });
        frame.getContentPane().add(creditBtn);

        JButton loanPaymentBtn = new JButton("Loan Payment");
        styleButton(loanPaymentBtn, new Color(135, 206, 250)); // Sky Blue
        loanPaymentBtn.setBounds(160, 130, 160, 35);
        loanPaymentBtn.addActionListener(e -> {
            frame.dispose();
            new LoanPayment(user);
        });
        frame.getContentPane().add(loanPaymentBtn);

        JButton loanApplicationBtn = new JButton("Loan Application");
        styleButton(loanApplicationBtn, new Color(100, 149, 237)); // Cornflower Blue
        loanApplicationBtn.setBounds(160, 180, 160, 35);
        loanApplicationBtn.addActionListener(e -> {
            frame.dispose();
            new ApplicationForm(user);
        });
        frame.getContentPane().add(loanApplicationBtn);

        JButton backButton = new JButton("Back");
        styleButton(backButton, new Color(200, 220, 240)); // Pale Blue
        backButton.setFont(new Font("SansSerif", Font.PLAIN, 12));
        backButton.setBounds(20, 260, 80, 25);
        backButton.addActionListener(e -> {
            frame.dispose();
            new MenuPage(user);
        });
        frame.getContentPane().add(backButton);
    }

    private void styleButton(JButton button, Color bgColor) {
        button.setFocusPainted(false);
        button.setBackground(bgColor);
        button.setForeground(Color.BLACK);
        button.setFont(new Font("SansSerif", Font.BOLD, 14));
        button.setBorder(BorderFactory.createLineBorder(new Color(180, 200, 220)));
    }
}
