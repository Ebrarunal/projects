package pack1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class PayDebtPage {
    private JFrame frame;
    private JTextField amountDueTextField;
    private User user;
    private double balance;
    private double debt;

    public PayDebtPage(User user) {
        this.user = user;

        frame = new JFrame("Pay Debt");
        frame.setSize(400, 350);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        JLabel titleLabel = new JLabel("Pay Your Debt");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setBounds(120, 10, 200, 30);
        frame.add(titleLabel);

        JLabel lblBalance = new JLabel("Balance:");
        lblBalance.setBounds(40, 60, 100, 25);
        frame.add(lblBalance);

        JTextArea balanceArea = new JTextArea();
        balanceArea.setBounds(160, 60, 150, 25);
        balanceArea.setEditable(false);
        frame.add(balanceArea);

        JLabel lblTotalDebt = new JLabel("Total Debt:");
        lblTotalDebt.setBounds(40, 100, 100, 25);
        frame.add(lblTotalDebt);

        JTextArea totalDebtArea = new JTextArea();
        totalDebtArea.setBounds(160, 100, 150, 25);
        totalDebtArea.setEditable(false);
        frame.add(totalDebtArea);

        JLabel lblMinPayment = new JLabel("Minimum Payment:");
        lblMinPayment.setBounds(40, 140, 120, 25);
        frame.add(lblMinPayment);

        JTextArea minPaymentArea = new JTextArea();
        minPaymentArea.setBounds(160, 140, 150, 25);
        minPaymentArea.setEditable(false);
        frame.add(minPaymentArea);

        JLabel lblAmountDue = new JLabel("Amount to Pay:");
        lblAmountDue.setBounds(40, 180, 120, 25);
        frame.add(lblAmountDue);

        amountDueTextField = new JTextField();
        amountDueTextField.setBounds(160, 180, 150, 25);
        frame.add(amountDueTextField);

        JButton payButton = new JButton("Pay");
        payButton.setBounds(220, 230, 90, 30);
        frame.add(payButton);

        JButton backButton = new JButton("Back");
        backButton.setBounds(40, 230, 90, 30);
        frame.add(backButton);

        // Load balance and debt info
        try (Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/bank", "root", "123456")) {

            String queryBalance = "SELECT balance FROM accounts WHERE customer_id = ?";
            PreparedStatement pst1 = con.prepareStatement(queryBalance);
            pst1.setString(1, user.getCustomerId());
            ResultSet rs1 = pst1.executeQuery();
            if (rs1.next()) {
                balance = rs1.getDouble("balance");
                balanceArea.setText(String.format("%.2f", balance));
            }

            String checkInstallments = "SELECT COUNT(*) AS count FROM cards WHERE customer_id = ? AND remaining_months IS NOT NULL";
            PreparedStatement checkPst = con.prepareStatement(checkInstallments);
            checkPst.setString(1, user.getCustomerId());
            ResultSet checkRs = checkPst.executeQuery();

            boolean hasInstallments = false;
            if (checkRs.next() && checkRs.getInt("count") > 0) {
                hasInstallments = true;
            }

            if (hasInstallments) {
                String query = "SELECT SUM(monthly_dept) AS total FROM cards WHERE customer_id = ? AND remaining_months IS NOT NULL";
                PreparedStatement pst = con.prepareStatement(query);
                pst.setString(1, user.getCustomerId());
                ResultSet rs = pst.executeQuery();
                if (rs.next()) {
                    debt = rs.getDouble("total");
                    totalDebtArea.setText(String.format("%.2f", debt));
                }
            } else {
                String query = "SELECT SUM(debt) AS total FROM cards WHERE customer_id = ? AND remaining_months IS NULL";
                PreparedStatement pst = con.prepareStatement(query);
                pst.setString(1, user.getCustomerId());
                ResultSet rs = pst.executeQuery();
                if (rs.next()) {
                    debt = rs.getDouble("total");
                    totalDebtArea.setText(String.format("%.2f", debt));
                }
            }

            double minPayment = debt * 0.20;
            minPaymentArea.setText(String.format("%.2f", minPayment));

        } catch (SQLException e) {
            e.printStackTrace();
        }

        payButton.addActionListener(e -> {
            try {
                double amountToPay = Double.parseDouble(amountDueTextField.getText());

                if (amountToPay > balance) {
                    JOptionPane.showMessageDialog(frame, "Insufficient balance!");
                    return;
                }

                try (
                		Connection con = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/bank", "root", "123456")) {
                    
                    String updateBalance = "UPDATE accounts SET balance = balance - ? WHERE customer_id = ?";
                    PreparedStatement pst1 = con.prepareStatement(updateBalance);
                    pst1.setDouble(1, amountToPay);
                    pst1.setString(2, user.getCustomerId());
                    pst1.executeUpdate();

                    String updateDebt = "UPDATE cards SET debt = debt - ? WHERE customer_id = ?";
                    PreparedStatement pst2 = con.prepareStatement(updateDebt);
                    pst2.setDouble(1, amountToPay);
                    pst2.setString(2, user.getCustomerId());
                    pst2.executeUpdate();

                    String updateMonths = "UPDATE cards SET remaining_months = remaining_months - 1 WHERE customer_id = ? AND remaining_months > 0";
                    PreparedStatement pst3 = con.prepareStatement(updateMonths);
                    pst3.setString(1, user.getCustomerId());
                    pst3.executeUpdate();

                    String deleteCleared = "DELETE FROM cards WHERE customer_id = ? AND (monthly_dept <= 0 OR remaining_months <= 0)";
                    PreparedStatement delPst = con.prepareStatement(deleteCleared);
                    delPst.setString(1, user.getCustomerId());
                    delPst.executeUpdate();

                    JOptionPane.showMessageDialog(frame, "Payment completed successfully!");
                    frame.dispose();
                    new CreditCardPage(user);

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(frame, "Database error occurred.");
                }

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Please enter a valid number.");
            }
        });

        backButton.addActionListener(e -> {
            frame.dispose();
            new CreditCardPage(user);
        });

        frame.setVisible(true);
    }
}
