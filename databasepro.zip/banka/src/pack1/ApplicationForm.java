package pack1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ApplicationForm {

    private JFrame frame;
    private JTextField amountField;
    private User user;

    public ApplicationForm(User user) {
        this.user = user;
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Loan Application");
        frame.setBounds(100, 100, 520, 350);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        frame.getContentPane().setBackground(new Color(200, 220, 240)); // Soft blue background

        Font labelFont = new Font("Segoe UI", Font.BOLD, 14);
        Font inputFont = new Font("Segoe UI", Font.PLAIN, 13);
        Color darkBlue = new Color(26, 35, 126);

        JLabel lblLoanType = new JLabel("Loan Type:");
        lblLoanType.setBounds(20, 30, 100, 20);
        lblLoanType.setFont(labelFont);
        lblLoanType.setForeground(darkBlue);
        frame.getContentPane().add(lblLoanType);

        JComboBox<String> comboBoxLoanType = new JComboBox<>();
        comboBoxLoanType.setBounds(130, 30, 120, 25);
        comboBoxLoanType.setFont(inputFont);
        comboBoxLoanType.addItem("Personal");
        comboBoxLoanType.addItem("Housing");
        comboBoxLoanType.addItem("Vehicle");
        frame.getContentPane().add(comboBoxLoanType);

        JLabel lblPeriod = new JLabel("Term (Months):");
        lblPeriod.setBounds(20, 70, 120, 20);
        lblPeriod.setFont(labelFont);
        lblPeriod.setForeground(darkBlue);
        frame.getContentPane().add(lblPeriod);

        JComboBox<String> comboBoxPeriod = new JComboBox<>();
        comboBoxPeriod.setBounds(130, 70, 60, 25);
        comboBoxPeriod.setFont(inputFont);
        for (int i = 1; i <= 12; i++) {
            comboBoxPeriod.addItem(String.valueOf(i));
        }
        frame.getContentPane().add(comboBoxPeriod);

        JLabel lblAmount = new JLabel("Amount (₺):");
        lblAmount.setBounds(20, 110, 100, 20);
        lblAmount.setFont(labelFont);
        lblAmount.setForeground(darkBlue);
        frame.getContentPane().add(lblAmount);

        amountField = new JTextField();
        amountField.setBounds(130, 110, 100, 25);
        amountField.setFont(inputFont);
        frame.getContentPane().add(amountField);

        JTextArea resultArea = new JTextArea();
        resultArea.setEditable(false);
        resultArea.setBounds(260, 20, 230, 200);
        resultArea.setFont(inputFont);
        frame.getContentPane().add(resultArea);

        JButton btnCalculate = new JButton("Calculate");
        btnCalculate.setBounds(30, 160, 110, 30);
        btnCalculate.setFont(labelFont);
        btnCalculate.setBackground(new Color(33, 150, 243));
        btnCalculate.setForeground(Color.WHITE);
        frame.getContentPane().add(btnCalculate);

        JButton btnApply = new JButton("Apply");
        btnApply.setBounds(150, 160, 110, 30);
        btnApply.setFont(labelFont);
        btnApply.setBackground(new Color(76, 175, 80));
        btnApply.setForeground(Color.WHITE);
        frame.getContentPane().add(btnApply);

        JButton btnBack = new JButton("Back");
        btnBack.setBounds(20, 240, 100, 30);
        btnBack.setFont(labelFont);
        btnBack.setBackground(new Color(255, 87, 34));
        btnBack.setForeground(Color.WHITE);
        btnBack.addActionListener(e -> {
            frame.dispose();
            new LoanTransactions(user);
        });
        frame.getContentPane().add(btnBack);

        btnCalculate.addActionListener(e -> {
            try {
                String loanType = (String) comboBoxLoanType.getSelectedItem();
                int years = Integer.parseInt((String) comboBoxPeriod.getSelectedItem());
                double amount = Double.parseDouble(amountField.getText());
                double interestRate;

                try (Connection conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/bank", "root", "123456")) {
                    String query = "SELECT rate FROM rate WHERE loan_type = ?";
                    try (PreparedStatement pst = conn.prepareStatement(query)) {
                        pst.setString(1, loanType.toLowerCase());
                        try (ResultSet rs = pst.executeQuery()) {
                            if (rs.next()) {
                                interestRate = rs.getDouble("rate");
                            } else {
                                resultArea.setText("Interest rate not found for selected loan type.");
                                return;
                            }
                        }
                    }
                }

                int totalMonths = years * 12;
                double interest = amount * interestRate * years;
                double totalPayment = amount + interest;
                double monthlyPayment = totalPayment / totalMonths;

                resultArea.setText(
                    "Interest Rate: " + String.format("%.2f", interestRate * 100) + " %\n" +
                    "Total Interest: ₺" + String.format("%.2f", interest) + "\n" +
                    "Total Payment: ₺" + String.format("%.2f", totalPayment) + "\n" +
                    "Monthly Payment: ₺" + String.format("%.2f", monthlyPayment)
                );

            } catch (Exception ex) {
                resultArea.setText("Calculation error: " + ex.getMessage());
            }
        });

        btnApply.addActionListener(e -> {
            try {
                String loanType = (String) comboBoxLoanType.getSelectedItem();
                int months = Integer.parseInt((String) comboBoxPeriod.getSelectedItem());
                double amount = Double.parseDouble(amountField.getText());

                LocalDate startDate = LocalDate.now();
                LocalDate endDate = startDate.plusMonths(months);
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

                try (Connection conn = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/bank", "root", "123456")) {
                    conn.setAutoCommit(false);

                    String updateBalance = "UPDATE accounts SET balance = balance + ? WHERE customer_id = ?";
                    try (PreparedStatement stmt = conn.prepareStatement(updateBalance)) {
                        stmt.setDouble(1, amount);
                        stmt.setString(2, user.getCustomerId());
                        stmt.executeUpdate();
                    }

                    String insertLoan = "INSERT INTO loans (customer_id, loan_type, main_amount, start_date, end_date, remaining_amount, remaining_months) VALUES (?, ?, ?, ?, ?, ?, ?)";
                    try (PreparedStatement pst = conn.prepareStatement(insertLoan)) {
                        pst.setString(1, user.getCustomerId());
                        pst.setString(2, loanType.toLowerCase());
                        pst.setDouble(3, amount);
                        pst.setString(4, startDate.format(formatter));
                        pst.setString(5, endDate.format(formatter));
                        pst.setDouble(6, amount);
                        pst.setInt(7, months);
                        pst.executeUpdate();
                    }

                    conn.commit();
                    JOptionPane.showMessageDialog(frame, "Loan successfully applied and saved to the database.");

                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(frame, "Database error: " + ex.getMessage());
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage());
            }
        });

        frame.setVisible(true);
    }
}
