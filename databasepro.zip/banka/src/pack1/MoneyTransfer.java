package pack1;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.*;

public class MoneyTransfer {

    private JFrame frame;
    private JTextField ibanField;
    private JTextField nameField; // Not used currently
    private JTextField amountField;
    private User user;

    public MoneyTransfer(User user) {
        this.user = user;
        initialize();
        frame.setVisible(true);
    }

    private void initialize() {
        frame = new JFrame("Money Transfer");
        frame.setBounds(100, 100, 500, 370);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        frame.getContentPane().setBackground(new Color(240, 245, 255));

        JLabel header = new JLabel("Transfer Money to Another Account");
        header.setFont(new Font("Segoe UI", Font.BOLD, 18));
        header.setBounds(60, 15, 400, 30);
        frame.getContentPane().add(header);

        JLabel lblIban = new JLabel("Recipient IBAN");
        lblIban.setBounds(40, 80, 100, 20);
        frame.getContentPane().add(lblIban);

        ibanField = new JTextField();
        ibanField.setBounds(160, 78, 200, 25);
        frame.getContentPane().add(ibanField);

        JLabel lblName = new JLabel("Recipient Name");
        lblName.setBounds(40, 115, 120, 20);
        frame.getContentPane().add(lblName);

        nameField = new JTextField();
        nameField.setBounds(160, 113, 200, 25);
        frame.getContentPane().add(nameField);

        JLabel lblAmount = new JLabel("Amount");
        lblAmount.setBounds(40, 150, 100, 20);
        frame.getContentPane().add(lblAmount);

        amountField = new JTextField();
        amountField.setBounds(160, 148, 200, 25);
        frame.getContentPane().add(amountField);

        JButton sendButton = new JButton("SEND");
        sendButton.setFont(new Font("Segoe UI", Font.BOLD, 13));
        sendButton.setBackground(new Color(0, 123, 255));
        sendButton.setForeground(Color.WHITE);
        sendButton.setBounds(180, 200, 100, 30);
        frame.getContentPane().add(sendButton);

        JButton backButton = new JButton("Back");
        backButton.setBounds(20, 290, 80, 25);
        frame.getContentPane().add(backButton);
        backButton.addActionListener(e -> {
            frame.dispose();
            new MenuPage(user);
        });

        JTextArea infoArea = new JTextArea();
        infoArea.setEditable(false);
        infoArea.setBackground(new Color(230, 240, 255));
        infoArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        infoArea.setBounds(40, 245, 400, 35);
        frame.getContentPane().add(infoArea);

        sendButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (user == null) {
                    JOptionPane.showMessageDialog(frame, "User information is missing.");
                    return;
                }

                String receiverAccount = ibanField.getText().trim();
                double amount;

                try {
                    amount = Double.parseDouble(amountField.getText().trim());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Please enter a valid amount.");
                    return;
                }

                try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root", "123456")) {
                    con.setAutoCommit(false);

                    String senderQuery = "SELECT account_number, balance FROM accounts WHERE customer_id = ?";
                    PreparedStatement senderStmt = con.prepareStatement(senderQuery);
                    senderStmt.setString(1, user.getCustomerId());
                    ResultSet senderRs = senderStmt.executeQuery();

                    if (!senderRs.next()) {
                        JOptionPane.showMessageDialog(frame, "Sender account not found.");
                        con.rollback();
                        return;
                    }

                    String senderAccount = senderRs.getString("account_number");
                    double senderBalance = senderRs.getDouble("balance");

                    if (senderBalance < amount) {
                        JOptionPane.showMessageDialog(frame, "Insufficient balance.");
                        con.rollback();
                        return;
                    }

                    // Deduct from sender
                    String updateSender = "UPDATE accounts SET balance = balance - ? WHERE account_number = ?";
                    PreparedStatement updateSenderStmt = con.prepareStatement(updateSender);
                    updateSenderStmt.setDouble(1, amount);
                    updateSenderStmt.setString(2, senderAccount);
                    updateSenderStmt.executeUpdate();

                  

                    con.commit();
                    infoArea.setText("Transfer successful!");

                    // Cleanup
                    senderRs.close();
                    senderStmt.close();
                    updateSenderStmt.close();
                   

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(frame, "Database error: " + ex.getMessage());
                }
            }
        });
    }
}
