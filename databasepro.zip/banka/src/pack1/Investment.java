package pack1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Investment {

    private JFrame frame;
    private JList<String> assetList;
    private JTextField amountField;
    private JLabel balanceLabel;
    private JLabel assetInfoLabel;
    private JLabel dollarLabel, euroLabel, goldLabel;
    private User user;

    public Investment(User user) {
        this.user = user;
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Investment Transactions");
        frame.setBounds(100, 100, 500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        frame.getContentPane().setBackground(new Color(187, 222, 251));

        Font labelFont = new Font("Segoe UI", Font.BOLD, 14);
        Font inputFont = new Font("Segoe UI", Font.PLAIN, 13);
        Color darkBlue = new Color(26, 35, 126);

        JLabel lblAssets = new JLabel("Asset Type:");
        lblAssets.setBounds(30, 20, 100, 20);
        lblAssets.setFont(labelFont);
        lblAssets.setForeground(darkBlue);
        frame.getContentPane().add(lblAssets);

        assetList = new JList<>(new String[]{"Dolar", "Euro", "Gold"});
        assetList.setBounds(30, 50, 120, 80);
        assetList.setFont(inputFont);
        frame.getContentPane().add(assetList);

        JLabel lblAmount = new JLabel("Amount (₺):");
        lblAmount.setBounds(180, 50, 100, 20);
        lblAmount.setFont(labelFont);
        lblAmount.setForeground(darkBlue);
        frame.getContentPane().add(lblAmount);

        amountField = new JTextField();
        amountField.setBounds(270, 48, 150, 25);
        amountField.setFont(inputFont);
        frame.getContentPane().add(amountField);

        JButton btnBuy = new JButton("Buy");
        btnBuy.setBounds(180, 90, 100, 30);
        btnBuy.setFont(labelFont);
        btnBuy.setBackground(new Color(33, 150, 243));
        btnBuy.setForeground(Color.WHITE);
        frame.getContentPane().add(btnBuy);

        JButton btnSell = new JButton("Sell");
        btnSell.setBounds(310, 90, 100, 30);
        btnSell.setFont(labelFont);
        btnSell.setBackground(new Color(255, 87, 34));
        btnSell.setForeground(Color.WHITE);
        frame.getContentPane().add(btnSell);

        JButton btnBack = new JButton("Back");
        btnBack.setBounds(30, 320, 100, 30);
        btnBack.setFont(labelFont);
        btnBack.setBackground(new Color(120, 144, 156));
        btnBack.setForeground(Color.WHITE);
        btnBack.addActionListener(e -> {
            frame.dispose();
            new MenuPage(user);
        });
        frame.getContentPane().add(btnBack);

        balanceLabel = new JLabel("Balance: ");
        balanceLabel.setBounds(30, 150, 300, 20);
        balanceLabel.setFont(labelFont);
        balanceLabel.setForeground(darkBlue);
        frame.getContentPane().add(balanceLabel);

        assetInfoLabel = new JLabel("Investment Info: ");
        assetInfoLabel.setBounds(30, 180, 400, 20);
        assetInfoLabel.setFont(labelFont);
        assetInfoLabel.setForeground(darkBlue);
        frame.getContentPane().add(assetInfoLabel);

        dollarLabel = new JLabel("Dolar: 0 $");
        dollarLabel.setBounds(30, 220, 200, 20);
        dollarLabel.setFont(labelFont);
        dollarLabel.setForeground(darkBlue);
        frame.getContentPane().add(dollarLabel);

        euroLabel = new JLabel("Euro: 0 €");
        euroLabel.setBounds(30, 245, 200, 20);
        euroLabel.setFont(labelFont);
        euroLabel.setForeground(darkBlue);
        frame.getContentPane().add(euroLabel);

        goldLabel = new JLabel("Gold: 0 gr");
        goldLabel.setBounds(30, 270, 200, 20);
        goldLabel.setFont(labelFont);
        goldLabel.setForeground(darkBlue);
        frame.getContentPane().add(goldLabel);

        btnBuy.addActionListener(e -> {
            buyAsset();
            loadQuantityTotals();
        });

        btnSell.addActionListener(e -> {
            sellAsset();
            loadQuantityTotals();
        });

        loadBalance();
        loadQuantityTotals();
        frame.setVisible(true);
    }

    private void loadBalance() {
        try (Connection con = connectDB();
             PreparedStatement ps = con.prepareStatement("SELECT balance FROM accounts WHERE customer_id = ?")) {
            ps.setInt(1, Integer.parseInt(user.getCustomerId()));
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                balanceLabel.setText("Balance: ₺" + rs.getDouble("balance"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateAssetInfo(String inv) {
        try (Connection con = connectDB();
             PreparedStatement ps = con.prepareStatement("SELECT price, quantity FROM investment WHERE customer_id = ? AND inv_name = ?")) {
            ps.setInt(1, Integer.parseInt(user.getCustomerId()));
            ps.setString(2, inv);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                assetInfoLabel.setText("Price: " + rs.getDouble("price") + " / Quantity: " + rs.getDouble("quantity"));
            } else {
                assetInfoLabel.setText("Price: - / Quantity: 0");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void buyAsset() {
        String selected = assetList.getSelectedValue();
        if (selected == null) return;

        double tlAmount;
        try {
            tlAmount = Double.parseDouble(amountField.getText());
            if (tlAmount <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Enter a valid amount in TL.");
            return;
        }

        try (Connection con = connectDB()) {
            con.setAutoCommit(false);

            double balance = getBalance(con);
            if (balance < tlAmount) {
                JOptionPane.showMessageDialog(frame, "Insufficient balance.");
                return;
            }

            double price = getPrice(con, selected);
            double quantity = tlAmount / price;

            PreparedStatement check = con.prepareStatement("SELECT quantity FROM investment WHERE customer_id = ? AND inv_name = ?");
            check.setInt(1, Integer.parseInt(user.getCustomerId()));
            check.setString(2, selected);
            ResultSet rs = check.executeQuery();

            if (rs.next()) {
                PreparedStatement updateInv = con.prepareStatement("UPDATE investment SET quantity = quantity + ? WHERE customer_id = ? AND inv_name = ?");
                updateInv.setDouble(1, quantity);
                updateInv.setInt(2, Integer.parseInt(user.getCustomerId()));
                updateInv.setString(3, selected);
                updateInv.executeUpdate();
            } else {
                PreparedStatement insertInv = con.prepareStatement("INSERT INTO investment (customer_id, inv_name, quantity, price) VALUES (?, ?, ?, ?)");
                insertInv.setInt(1, Integer.parseInt(user.getCustomerId()));
                insertInv.setString(2, selected);
                insertInv.setDouble(3, quantity);
                insertInv.setDouble(4, price);
                insertInv.executeUpdate();
            }

            PreparedStatement updateBal = con.prepareStatement("UPDATE accounts SET balance = balance - ? WHERE customer_id = ?");
            updateBal.setDouble(1, tlAmount);
            updateBal.setInt(2, Integer.parseInt(user.getCustomerId()));
            updateBal.executeUpdate();

            con.commit();
            JOptionPane.showMessageDialog(frame, quantity + " units of " + selected + " purchased.");
            loadBalance();
            updateAssetInfo(selected);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void sellAsset() {
        String selected = assetList.getSelectedValue();
        if (selected == null) return;

        double tlAmount;
        try {
            tlAmount = Double.parseDouble(amountField.getText());
            if (tlAmount <= 0) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Enter a valid amount in TL.");
            return;
        }

        try (Connection con = connectDB()) {
            con.setAutoCommit(false);

            double price = getPrice(con, selected);
            double quantityToSell = tlAmount / price;

            PreparedStatement ps = con.prepareStatement("SELECT quantity FROM investment WHERE customer_id = ? AND inv_name = ?");
            ps.setInt(1, Integer.parseInt(user.getCustomerId()));
            ps.setString(2, selected);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                double currentQty = rs.getDouble("quantity");
                if (currentQty < quantityToSell) {
                    JOptionPane.showMessageDialog(frame, "Insufficient " + selected + " to sell.");
                    return;
                }

                PreparedStatement updateQty = con.prepareStatement("UPDATE investment SET quantity = quantity - ? WHERE customer_id = ? AND inv_name = ?");
                updateQty.setDouble(1, tlAmount);
                updateQty.setInt(2, Integer.parseInt(user.getCustomerId()));
                updateQty.setString(3, selected);
                updateQty.executeUpdate();

                PreparedStatement updateBal = con.prepareStatement("UPDATE accounts SET balance = balance + ? WHERE customer_id = ?");
                updateBal.setDouble(1, tlAmount);
                updateBal.setInt(2, Integer.parseInt(user.getCustomerId()));
                updateBal.executeUpdate();

                con.commit();
                JOptionPane.showMessageDialog(frame, String.format("%.2f units of %s sold. ₺%.2f added to balance.", quantityToSell, selected, tlAmount));
                loadBalance();
                updateAssetInfo(selected);

            } else {
                JOptionPane.showMessageDialog(frame, "You don't own any " + selected + " to sell.");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadQuantityTotals() {
        String[] assets = {"Dolar", "Euro", "Gold"};
        JLabel[] labels = {dollarLabel, euroLabel, goldLabel};
        String[] suffixes = {" $", " €", " gr"};

        try (Connection con = connectDB()) {
            for (int i = 0; i < assets.length; i++) {
                String asset = assets[i];
                PreparedStatement ps = con.prepareStatement("SELECT quantity FROM investment WHERE customer_id = ? AND inv_name = ?");
                ps.setInt(1, Integer.parseInt(user.getCustomerId()));
                ps.setString(2, asset);
                ResultSet rs = ps.executeQuery();

                double quantity = 0;
                if (rs.next()) {
                    quantity = rs.getDouble("quantity");
                }

                labels[i].setText(asset + ": " + String.format("%.2f", quantity) + suffixes[i]);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private double getPrice(Connection con, String invName) throws SQLException {
        PreparedStatement ps = con.prepareStatement("SELECT price FROM investment WHERE inv_name = ? AND customer_id IS NULL");
        ps.setString(1, invName);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return rs.getDouble("price");
        } else {
            JOptionPane.showMessageDialog(frame, "Price not found for " + invName + ". Please add it to the database.");
            throw new SQLException("Price not found for " + invName);
        }
    }

    private double getBalance(Connection con) throws SQLException {
        PreparedStatement ps = con.prepareStatement("SELECT balance FROM accounts WHERE customer_id = ?");
        ps.setInt(1, Integer.parseInt(user.getCustomerId()));
        ResultSet rs = ps.executeQuery();
        if (rs.next()) return rs.getDouble("balance");
        throw new SQLException("Balance not found.");
    }

    private Connection connectDB() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root", "123456");
    }
}