package pack1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CreditCardPage {

    private JFrame frame;
    private User user;

    public CreditCardPage(User user) {
        this.user = user;
        initialize();
        frame.setVisible(true);
    }

    private void initialize() {
        frame = new JFrame("Credit Card Services");
        frame.setBounds(100, 100, 420, 320);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        frame.getContentPane().setBackground(new Color(245, 250, 255));

        JLabel title = new JLabel("Credit Card Operations");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setBounds(93, 31, 250, 30);
        frame.getContentPane().add(title);

        JButton cashAdvanceButton = new JButton("Cash Advance");
        cashAdvanceButton.setBounds(120, 88, 160, 35);
        frame.getContentPane().add(cashAdvanceButton);

    

        JButton payDebtButton = new JButton("Pay Credit Debt");
        payDebtButton.setBounds(120, 133, 160, 35);
        frame.getContentPane().add(payDebtButton);

        JButton backButton = new JButton("Back");
        backButton.setBounds(25, 214, 80, 25);
        frame.getContentPane().add(backButton);

        // Navigation
        backButton.addActionListener(e -> {
            frame.dispose();
            new MenuPage(user);
        });

        cashAdvanceButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new CashAdvancesPage(user);
            }
        });

     

        payDebtButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
                new PayDebtPage(user);
            }
        });
    }
}
