package pack1;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class MainPanel {
    private JFrame frmMainPage;
    private User user;

    public MainPanel(User user) {
        this.user = user;

        frmMainPage = new JFrame("Dashboard");
        frmMainPage.setBounds(100, 100, 500, 400);
        frmMainPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frmMainPage.getContentPane().setLayout(null);
        frmMainPage.getContentPane().setBackground(new Color(240, 245, 255));

        JLabel lblTitle = new JLabel("Account Summary");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitle.setBounds(120, 10, 250, 30);
        frmMainPage.getContentPane().add(lblTitle);

        JLabel lblBalance = new JLabel("Available Balance:");
        lblBalance.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblBalance.setBounds(60, 60, 130, 25);
        frmMainPage.getContentPane().add(lblBalance);

        JTextField balanceField = new JTextField();
        balanceField.setEditable(false);
        balanceField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        balanceField.setBounds(200, 60, 200, 25);
        frmMainPage.getContentPane().add(balanceField);

        JLabel lblIban = new JLabel("Account Number:");
        lblIban.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblIban.setBounds(60, 95, 130, 25);
        frmMainPage.getContentPane().add(lblIban);

        JTextField ibanField = new JTextField();
        ibanField.setEditable(false);
        ibanField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        ibanField.setBounds(200, 95, 200, 25);
        frmMainPage.getContentPane().add(ibanField);

        JLabel lblDetails = new JLabel("Loans & Investments:");
        lblDetails.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblDetails.setBounds(60, 135, 200, 20);
        frmMainPage.getContentPane().add(lblDetails);

        JTextArea detailsArea = new JTextArea();
        detailsArea.setEditable(false);
        detailsArea.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        JScrollPane scrollPane = new JScrollPane(detailsArea);
        scrollPane.setBounds(60, 160, 380, 150);
        frmMainPage.getContentPane().add(scrollPane);

        JButton menuBtn = new JButton("Menu");
        menuBtn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        menuBtn.setBounds(190, 320, 100, 30);
        menuBtn.setBackground(new Color(0, 102, 204));
        menuBtn.setForeground(Color.WHITE);
        frmMainPage.getContentPane().add(menuBtn);

        // Database Access
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root", "123456")) {

            // ACCOUNT
            String queryAcc = "SELECT account_number, balance FROM accounts WHERE customer_id = ?";
            PreparedStatement pst = con.prepareStatement(queryAcc);
            pst.setString(1, user.getCustomerId());

            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                ibanField.setText(rs.getString("account_number"));
                balanceField.setText(rs.getDouble("balance") + " ₺");
            } else {
                ibanField.setText("-");
                balanceField.setText("0 ₺");
                detailsArea.setText("No account found.");
            }
            rs.close();
            pst.close();

            // LOANS
            StringBuilder infoBuilder = new StringBuilder();
            String loanQuery = "SELECT loan_type, main_amount FROM loans WHERE customer_id = ?";
            pst = con.prepareStatement(loanQuery);
            pst.setString(1, user.getCustomerId());
            rs = pst.executeQuery();

            infoBuilder.append("---- Loans ----\n");
            boolean hasLoan = false;
            while (rs.next()) {
                hasLoan = true;
                infoBuilder.append("Type: ").append(rs.getString("loan_type"))
                           .append(" | Amount: ").append(rs.getDouble("main_amount")).append(" ₺\n");
            }
            if (!hasLoan) infoBuilder.append("No loan data available.\n");

            rs.close();
            pst.close();

            // INVESTMENTS
            String invQuery = "SELECT inv_name, quantity FROM investment";
            pst = con.prepareStatement(invQuery);
            rs = pst.executeQuery();

            infoBuilder.append("\n---- Investments ----\n");
            boolean hasInv = false;
            while (rs.next()) {
                hasInv = true;
                infoBuilder.append("Name: ").append(rs.getString("inv_name"))
                           .append(" | Quantity: ").append(rs.getDouble("quantity")).append("\n");
            }
            if (!hasInv) infoBuilder.append("No investment data available.\n");

            detailsArea.setText(infoBuilder.toString());

            rs.close();
            pst.close();

        } catch (Exception e) {
            e.printStackTrace();
            detailsArea.setText("Database error: " + e.getMessage());
            balanceField.setText("ERROR");
            ibanField.setText("ERROR");
        }

        menuBtn.addActionListener(e -> {
            frmMainPage.dispose();
            new MenuPage(user);
        });

        frmMainPage.setVisible(true);
    }
}
