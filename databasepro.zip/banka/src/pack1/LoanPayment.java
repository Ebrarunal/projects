package pack1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.Period;

public class LoanPayment {
    private JFrame frame;
    private JTextField textFieldAmountDue;
    private User user;
    private double balance;
    private double totalRemainingAmount;
    private double monthlyInstallment;

    public LoanPayment(User user) {
        this.user = user;
        frame = new JFrame("Loan Payment");
        frame.setBounds(100, 100, 450, 380);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        frame.getContentPane().setBackground(new Color(234, 246, 255)); // #EAF6FF

        JLabel titleLabel = new JLabel("Loan Payment");
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
        titleLabel.setForeground(new Color(30, 60, 90));
        titleLabel.setBounds(140, 10, 200, 30);
        frame.getContentPane().add(titleLabel);

        JLabel lblBalance = new JLabel("Your Balance:");
        lblBalance.setBounds(40, 60, 140, 20);
        frame.getContentPane().add(lblBalance);

        JTextArea balanceArea = createInfoArea();
        balanceArea.setBounds(200, 60, 150, 25);
        frame.getContentPane().add(balanceArea);

        JLabel lblTotalLoan = new JLabel("Remaining Loan:");
        lblTotalLoan.setBounds(40, 100, 140, 20);
        frame.getContentPane().add(lblTotalLoan);

        JTextArea totalLoanArea = createInfoArea();
        totalLoanArea.setBounds(200, 100, 150, 25);
        frame.getContentPane().add(totalLoanArea);

        JLabel lblMonthlyInstallment = new JLabel("Monthly Installment:");
        lblMonthlyInstallment.setBounds(40, 140, 150, 20);
        frame.getContentPane().add(lblMonthlyInstallment);

        JTextArea installmentArea = createInfoArea();
        installmentArea.setBounds(200, 140, 150, 25);
        frame.getContentPane().add(installmentArea);

        JLabel lblAmountDue = new JLabel("Amount to Pay:");
        lblAmountDue.setBounds(40, 180, 150, 20);
        frame.getContentPane().add(lblAmountDue);

        textFieldAmountDue = new JTextField();
        textFieldAmountDue.setBounds(200, 180, 150, 25);
        textFieldAmountDue.setFont(new Font("SansSerif", Font.PLAIN, 14));
        frame.getContentPane().add(textFieldAmountDue);

        JButton btnPay = new JButton("Pay");
        btnPay.setBounds(200, 220, 100, 30);
        styleButton(btnPay);
        frame.getContentPane().add(btnPay);

        JButton backButton = new JButton("Back");
        backButton.setBounds(20, 300, 80, 25);
        styleButton(backButton);
        frame.getContentPane().add(backButton);

        backButton.addActionListener(e -> {
            frame.dispose();
            new LoanTransactions(user);
        });

        // Load data
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root", "123456")) {
            String sqlBalance = "SELECT balance FROM accounts WHERE customer_id = ?";
            PreparedStatement pst1 = con.prepareStatement(sqlBalance);
            pst1.setString(1, user.getCustomerId());
            ResultSet rs1 = pst1.executeQuery();
            if (rs1.next()) {
                balance = rs1.getDouble("balance");
                balanceArea.setText(String.format("%.2f", balance));
            }

            String sqlLoan = "SELECT SUM(remaining_amount) AS totalRemaining, " +
                    "SUM(remaining_amount / TIMESTAMPDIFF(MONTH, start_date, end_date)) AS monthly " +
                    "FROM loans WHERE customer_id = ?";
            PreparedStatement pst2 = con.prepareStatement(sqlLoan);
            pst2.setString(1, user.getCustomerId());
            ResultSet rs2 = pst2.executeQuery();
            if (rs2.next()) {
                totalRemainingAmount = rs2.getDouble("totalRemaining");
                monthlyInstallment = rs2.getDouble("monthly");
                totalLoanArea.setText(String.format("%.2f", totalRemainingAmount));
                installmentArea.setText(String.format("%.2f", monthlyInstallment));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        btnPay.addActionListener(e -> {
            try {
                double amountDue = Double.parseDouble(textFieldAmountDue.getText());

                if (amountDue > balance) {
                    JOptionPane.showMessageDialog(frame, "Insufficient balance!");
                    return;
                }

                try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root", "123456")) {
                    con.setAutoCommit(false);

                    String sql1 = "UPDATE accounts SET balance = balance - ? WHERE customer_id = ?";
                    PreparedStatement pst1 = con.prepareStatement(sql1);
                    pst1.setDouble(1, amountDue);
                    pst1.setString(2, user.getCustomerId());
                    pst1.executeUpdate();

                    String sqlLoans = "SELECT loan_id, remaining_amount, main_amount, start_date, end_date " +
                            "FROM loans WHERE customer_id = ? AND remaining_amount > 0";
                    PreparedStatement pst2 = con.prepareStatement(sqlLoans);
                    pst2.setString(1, user.getCustomerId());
                    ResultSet rs = pst2.executeQuery();

                    double remaining = amountDue;

                    while (rs.next() && remaining > 0) {
                        int loanId = rs.getInt("loan_id");
                        double loanRemaining = rs.getDouble("remaining_amount");
                        double mainAmount = rs.getDouble("main_amount");
                        Date startDate = rs.getDate("start_date");
                        Date endDate = rs.getDate("end_date");

                        if (startDate == null || endDate == null) continue;

                        int months = Period.between(startDate.toLocalDate(), endDate.toLocalDate()).getMonths();
                        months = Math.max(months, 1);
                        double monthly = loanRemaining / months;
                        double payAmount = Math.min(monthly, remaining);

                        String sqlUpdateLoan = "UPDATE loans SET " +
                                "remaining_amount = remaining_amount - ?, " +
                                "main_amount = main_amount - ?, " +
                                "end_date = DATE_SUB(end_date, INTERVAL 1 MONTH) " +
                                "WHERE loan_id = ?";
                        PreparedStatement pstUpdate = con.prepareStatement(sqlUpdateLoan);
                        pstUpdate.setDouble(1, payAmount);
                        pstUpdate.setDouble(2, payAmount);
                        pstUpdate.setInt(3, loanId);
                        pstUpdate.executeUpdate();

                        String sqlUpdateMonths = "UPDATE loans SET remaining_months = remaining_months - 1 " +
                                "WHERE loan_id = ? AND remaining_months > 0";
                        PreparedStatement pstMonths = con.prepareStatement(sqlUpdateMonths);
                        pstMonths.setInt(1, loanId);
                        pstMonths.executeUpdate();

                        remaining -= payAmount;
                    }

                    con.commit();
                    JOptionPane.showMessageDialog(frame, "Payment successful!");
                    frame.dispose();
                    new LoanTransactions(user);

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(frame, "Error during transaction!");
                }

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Please enter a valid amount!");
            }
        });

        frame.setVisible(true);
    }

    private JTextArea createInfoArea() {
        JTextArea area = new JTextArea();
        area.setEditable(false);
        area.setFont(new Font("SansSerif", Font.PLAIN, 14));
        area.setBackground(Color.WHITE);
        area.setBorder(BorderFactory.createLineBorder(new Color(180, 200, 220)));
        return area;
    }

    private void styleButton(JButton button) {
        button.setBackground(new Color(200, 220, 240));
        button.setForeground(Color.BLACK);
        button.setFont(new Font("SansSerif", Font.BOLD, 14));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(new Color(180, 200, 220)));
    }
}
