package pack1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;

public class CashAdvancesPage {

    private JFrame frame;
    private JTextField amountTextField;
    private User user;

    public CashAdvancesPage(User user) {
        this.user = user;
        initialize();
        frame.setVisible(true);
    }

    private void initialize() {
        frame = new JFrame("Cash Advance");
        frame.setBounds(100, 100, 600, 530);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        frame.getContentPane().setBackground(new Color(245, 250, 255));

        JLabel titleLabel = new JLabel("Cash Advance Service");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setBounds(190, 20, 250, 30);
        frame.getContentPane().add(titleLabel);

        JLabel lblAmount = new JLabel("Transaction Amount:");
        lblAmount.setBounds(40, 70, 160, 25);
        frame.getContentPane().add(lblAmount);

        amountTextField = new JTextField();
        amountTextField.setBounds(220, 70, 180, 25);
        frame.getContentPane().add(amountTextField);
        amountTextField.setColumns(10);

        JLabel lblMonths = new JLabel("Installment Months:");
        lblMonths.setBounds(40, 115, 160, 25);
        frame.getContentPane().add(lblMonths);

        JComboBox<Integer> monthComboBox = new JComboBox<>();
        monthComboBox.setBounds(220, 115, 180, 25);
        for (int i = 1; i <= 12; i++) {
            monthComboBox.addItem(i);
        }
        frame.getContentPane().add(monthComboBox);

        JLabel lblInterest = new JLabel("Interest Rate:");
        lblInterest.setBounds(40, 160, 160, 25);
        frame.getContentPane().add(lblInterest);

        JTextArea interestRateText = new JTextArea("%4.69");
        interestRateText.setEditable(false);
        interestRateText.setBounds(220, 160, 180, 25);
        frame.getContentPane().add(interestRateText);

        JTextArea resultTextArea = new JTextArea();
        resultTextArea.setEditable(false);
        resultTextArea.setBounds(40, 250, 250, 120);
        frame.getContentPane().add(resultTextArea);

        JButton calculateButton = new JButton("Calculate");
        calculateButton.setBounds(400, 240, 120, 30);
        frame.getContentPane().add(calculateButton);
        calculateButton.addActionListener(e -> {
            try {
                double interestRate = 0.0469;
                double amount = Double.parseDouble(amountTextField.getText());
                int months = (Integer) monthComboBox.getSelectedItem();

                double totalInterest = amount * interestRate * months;
                double totalRepayment = amount + totalInterest;
                double monthlyPayment = totalRepayment / months;

                resultTextArea.setText("Interest: " + String.format("%.2f", totalInterest) + " ₺\n" +
                        "Total Repayment: " + String.format("%.2f", totalRepayment) + " ₺\n" +
                        "Monthly Payment: " + String.format("%.2f", monthlyPayment) + " ₺");

            } catch (NumberFormatException ex) {
                resultTextArea.setText("Please enter a valid amount.");
            }
        });

        JButton advanceButton = new JButton("Get Cash Advance");
        advanceButton.setBounds(320, 320, 180, 35);
        frame.getContentPane().add(advanceButton);
        advanceButton.addActionListener(e -> {
            try {
                double interestRate = 0.0469;
                double amount = Double.parseDouble(amountTextField.getText());
                int months = (Integer) monthComboBox.getSelectedItem();

                double totalInterest = amount * interestRate * months;
                double totalRepayment = amount + totalInterest;
                double monthlyPayment = totalRepayment / months;

                try (Connection con = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/bank", "root", "123456")) {

                    con.setAutoCommit(false);

                    // 1. Add amount (without interest) to accounts
                    String updateBalanceQuery = "UPDATE accounts SET balance = balance + ? WHERE customer_id = ?";
                    PreparedStatement pst1 = con.prepareStatement(updateBalanceQuery);
                    pst1.setDouble(1, amount);
                    pst1.setString(2, user.getCustomerId());
                    pst1.executeUpdate();

                    // 2. Add full debt (with interest) to cards
                    String updateDebtQuery = "UPDATE cards SET debt = debt + ? WHERE customer_id = ?";
                    PreparedStatement pst2 = con.prepareStatement(updateDebtQuery);
                    pst2.setDouble(1, totalRepayment);
                    pst2.setString(2, user.getCustomerId());
                    pst2.executeUpdate();

                    // 3. Add monthly installment info to installments table
                    String insertInstallmentQuery = "INSERT INTO cards (customer_id, monthly_dept, remaining_months) VALUES (?, ?, ?)";
                    PreparedStatement pst3 = con.prepareStatement(insertInstallmentQuery);
                    pst3.setString(1, user.getCustomerId());
                    pst3.setDouble(2, monthlyPayment);
                    pst3.setInt(3, months);
                    pst3.executeUpdate();

                    con.commit();

                    JOptionPane.showMessageDialog(frame, "Cash advance added successfully!");
                    frame.dispose();
                    new CreditCardPage(user);

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(frame, "Database error: " + ex.getMessage());
                }

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Please enter a valid amount.");
            }
        });

        JButton backButton = new JButton("Back");
        backButton.setBounds(20, 450, 80, 25);
        frame.getContentPane().add(backButton);
        backButton.addActionListener(e -> {
            frame.dispose();
            new CreditCardPage(user);
        });
    }
}
