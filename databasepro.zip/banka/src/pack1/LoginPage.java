package pack1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.sql.*;

public class LoginPage {

    private JFrame frame;
    private JTextField nameField;
    private JPasswordField passwordField;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                LoginPage window = new LoginPage();
                window.frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Application could not start!");
            }
        });
    }

    public LoginPage() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setTitle("Bank Login");
        frame.setBounds(100, 100, 450, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        frame.getContentPane().setBackground(new Color(240, 245, 255));

        JLabel titleLabel = new JLabel("Welcome to MyBank");
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(new Color(0, 51, 102));
        titleLabel.setBounds(90, 30, 270, 40);
        frame.getContentPane().add(titleLabel);

        JLabel nameLabel = new JLabel("Username:");
        nameLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        nameLabel.setBounds(70, 100, 120, 25);
        frame.getContentPane().add(nameLabel);

        nameField = new JTextField();
        nameField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        nameField.setBounds(170, 100, 180, 25);
        frame.getContentPane().add(nameField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        passwordLabel.setBounds(70, 150, 120, 25);
        frame.getContentPane().add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        passwordField.setBounds(170, 150, 180, 25);
        frame.getContentPane().add(passwordField);

        JButton loginButton = new JButton("Login");
        loginButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        loginButton.setBackground(new Color(0, 102, 204));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        loginButton.setBounds(160, 210, 120, 35);
        frame.getContentPane().add(loginButton);

        loginButton.addActionListener((ActionEvent e) -> {
            String name = nameField.getText().trim();
            String password = new String(passwordField.getPassword()).trim();

            if (name.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill in all fields.");
                return;
            }

            try (Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/bank", "root", "123456")) {

                String query = "SELECT * FROM login_logs WHERE nick_name = ? AND password = ?";
                PreparedStatement pst = con.prepareStatement(query);
                pst.setString(1, name);
                pst.setString(2, password);

                ResultSet rs = pst.executeQuery();

                if (rs.next()) {
                    String customerId = rs.getString("customer_id");
                    JOptionPane.showMessageDialog(frame, "Login successful! Welcome, " + name);

                    User user = new User(name, password, customerId);
                    frame.dispose();
                    new MainPanel(user);
                } else {
                    JOptionPane.showMessageDialog(frame, "Incorrect username or password.");
                }

                rs.close();
                pst.close();

            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(frame, "Database error: " + ex.getMessage());
            }
        });

        JLabel footerLabel = new JLabel("© 2025 MyBank Corp.");
        footerLabel.setHorizontalAlignment(SwingConstants.CENTER);
        footerLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        footerLabel.setForeground(Color.GRAY);
        footerLabel.setBounds(120, 320, 200, 20);
        frame.getContentPane().add(footerLabel);
    }
}
