package pack1;

import javax.swing.*;
import java.awt.*;

public class MenuPage {
    private JFrame frame;
    private User user;

    public MenuPage(User user) {
        this.user = user;

        frame = new JFrame("Main Menu");
        frame.setBounds(100, 100, 500, 420);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        frame.getContentPane().setBackground(new Color(240, 245, 255));

        JLabel titleLabel = new JLabel("Welcome to Your Banking Menu");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setBounds(50, 20, 400, 30);
        frame.getContentPane().add(titleLabel);

        Font buttonFont = new Font("Segoe UI", Font.PLAIN, 14);
        Color buttonBg = new Color(0, 102, 204);
        Color buttonFg = Color.WHITE;

        JButton transferBtn = new JButton("Money Transfers");
        transferBtn.setFont(buttonFont);
        transferBtn.setBackground(buttonBg);
        transferBtn.setForeground(buttonFg);
        transferBtn.setBounds(140, 80, 200, 35);
        frame.getContentPane().add(transferBtn);
        transferBtn.addActionListener(e -> {
            frame.dispose();
            new MoneyTransfer(user);
        });

        JButton cardBtn = new JButton("Credit Card");
        cardBtn.setFont(buttonFont);
        cardBtn.setBackground(buttonBg);
        cardBtn.setForeground(buttonFg);
        cardBtn.setBounds(140, 125, 200, 35);
        frame.getContentPane().add(cardBtn);
        cardBtn.addActionListener(e -> {
            frame.dispose();
            new CreditCardPage(user);
        });

       

        JButton investmentBtn = new JButton("Investments");
        investmentBtn.setFont(buttonFont);
        investmentBtn.setBackground(buttonBg);
        investmentBtn.setForeground(buttonFg);
        investmentBtn.setBounds(140, 170, 200, 35);
        frame.getContentPane().add(investmentBtn);
        investmentBtn.addActionListener(e -> {
            frame.dispose();
            new Investment(user);
        });

        JButton loanBtn = new JButton("Loan Transactions");
        loanBtn.setFont(buttonFont);
        loanBtn.setBackground(buttonBg);
        loanBtn.setForeground(buttonFg);
        loanBtn.setBounds(140, 215, 200, 35);
        frame.getContentPane().add(loanBtn);
        loanBtn.addActionListener(e -> {
            frame.dispose();
            new LoanTransactions(user);
        });

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        logoutBtn.setBackground(new Color(220, 53, 69));
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setBounds(189, 287, 100, 30);
        frame.getContentPane().add(logoutBtn);
        logoutBtn.addActionListener(e -> {
            frame.dispose();
            new LoginPage(); // Kullanıcı tekrar giriş sayfasına dönüyor
        });
        JButton backBtn = new JButton("Back");
        backBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        backBtn.setBackground(new Color(108, 117, 125)); // Gri ton
        backBtn.setForeground(Color.WHITE);
        backBtn.setBounds(189, 330, 100, 30);
        frame.getContentPane().add(backBtn);
        backBtn.addActionListener(e -> {
            frame.dispose();
            new MainPanel(user); // Ana panele geri dön
        });

        frame.setVisible(true);
    }
}
