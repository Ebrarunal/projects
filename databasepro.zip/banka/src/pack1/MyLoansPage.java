package pack1;

import java.awt.*;
import java.sql.*;
import javax.swing.*;

public class MyLoansPage {

    private JFrame frame;
    private JTextArea textArea;
    private User user;

    public MyLoansPage(User user) {
        this.user = user;
        initialize();
        loadLoans();
    }

    private void initialize() {
        frame = new JFrame("My Loans");
        frame.setBounds(100, 100, 520, 380);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        frame.getContentPane().setBackground(new Color(234, 246, 255)); // #EAF6FF

        JLabel titleLabel = new JLabel("Your Loan Details");
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
        titleLabel.setForeground(new Color(30, 60, 90));
        titleLabel.setBounds(160, 10, 300, 30);
        frame.getContentPane().add(titleLabel);

        textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setFont(new Font("SansSerif", Font.PLAIN, 14));
        textArea.setBackground(Color.WHITE);
        textArea.setBorder(BorderFactory.createLineBorder(new Color(180, 200, 220)));

        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setBounds(40, 50, 420, 230);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(180, 200, 220)));
        frame.getContentPane().add(scrollPane);

        JButton backBtn = new JButton("Back");
        backBtn.setBounds(20, 295, 80, 30);
        styleButton(backBtn, new Color(200, 220, 240));
        backBtn.setFont(new Font("SansSerif", Font.PLAIN, 12));
        backBtn.addActionListener(e -> {
            frame.dispose();
            new LoanTransactions(user);
        });
        frame.getContentPane().add(backBtn);

        frame.setVisible(true);
    }

    private void styleButton(JButton button, Color bgColor) {
        button.setFocusPainted(false);
        button.setBackground(bgColor);
        button.setForeground(Color.BLACK);
        button.setFont(new Font("SansSerif", Font.BOLD, 14));
        button.setBorder(BorderFactory.createLineBorder(new Color(180, 200, 220)));
    }

    private void loadLoans() {
        try (Connection con = connectDB()) {
            String sql = "SELECT loan_type, main_amount, start_date, end_date FROM loans WHERE customer_id = ?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(user.getCustomerId()));
            ResultSet rs = ps.executeQuery();

            StringBuilder sb = new StringBuilder();
            while (rs.next()) {
                String type = rs.getString("loan_type");
                double amount = rs.getDouble("main_amount");
                Date start = rs.getDate("start_date");
                Date end = rs.getDate("end_date");

                sb.append("Loan Type: ").append(type)
                  .append("\nAmount: ").append(amount)
                  .append("\nStart Date: ").append(start)
                  .append("\nEnd Date: ").append(end)
                  .append("\n-----------------------------\n");
            }

            if (sb.length() == 0) {
                sb.append("You don't have any registered loans.");
            }

            textArea.setText(sb.toString());

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "An error occurred while loading your loans.");
        }
    }

    private Connection connectDB() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root", "123456");
    }
}
