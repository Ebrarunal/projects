package bank;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class banks{

	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) throws SQLException {
	
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bank", "root", "123456");
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select* from customer");
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" ");
		}
	}}

	
	
